import { useEffect, useState } from 'react';
import { loadProgress, saveProgress, type Progress } from '@/lib/progressStorage';

export type ProgressActions = {
  setStartDate: (iso: string) => void;
  setDayChecks: (iso: string, names: string[]) => void;
  toggleExercise: (iso: string, name: string) => void;
  replaceProgress: (next: Progress) => void;
};

export function useProgress(todayISO: string): { progress: Progress } & ProgressActions {
  const [progress, setProgress] = useState<Progress>(() => loadProgress(todayISO));

  useEffect(() => {
    saveProgress(progress);
  }, [progress]);

  return {
    progress,
    setStartDate: (iso) => setProgress((p) => ({ ...p, startDate: iso })),
    setDayChecks: (iso, names) =>
      setProgress((p) => ({ ...p, checks: { ...p.checks, [iso]: names } })),
    toggleExercise: (iso, name) =>
      setProgress((p) => {
        const current = p.checks[iso] ?? [];
        const next = current.includes(name)
          ? current.filter((n) => n !== name)
          : [...current, name];
        return { ...p, checks: { ...p.checks, [iso]: next } };
      }),
    replaceProgress: (next) => setProgress(next),
  };
}
