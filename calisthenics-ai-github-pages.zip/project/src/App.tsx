import { useCallback, useMemo, useState } from 'react';
import NavBar, { type TabId } from '@/components/NavBar';
import DayDetailModal from '@/components/DayDetailModal';
import TodayView from '@/views/TodayView';
import WeekView from '@/views/WeekView';
import MonthView from '@/views/MonthView';
import PlanView from '@/views/PlanView';
import DataView from '@/views/DataView';
import { useProgress } from '@/hooks/useProgress';
import { parseISODate, toISODate } from '@/lib/dates';
import { buildChallengeDays, buildProgramDay } from '@/lib/program';

export default function App() {
  const todayISO = toISODate(new Date());
  const { progress, ...actions } = useProgress(todayISO);
  const [tab, setTab] = useState<TabId>('today');
  const [selectedIso, setSelectedIso] = useState<string | null>(null);

  const challengeDays = useMemo(() => buildChallengeDays(progress.startDate), [progress.startDate]);
  const selectedDay = selectedIso
    ? buildProgramDay(progress.startDate, parseISODate(selectedIso))
    : null;
  const closeDay = useCallback(() => setSelectedIso(null), []);

  return (
    <div className="min-h-screen bg-zinc-950 bg-[radial-gradient(ellipse_at_top,_rgba(57,255,20,0.07),_transparent_55%)]">
      <NavBar active={tab} onChange={setTab} />

      <main className="mx-auto max-w-6xl px-4 pb-28 pt-6 sm:px-6 md:pb-16 md:pt-8">
        {tab === 'today' && (
          <TodayView
            progress={progress}
            todayISO={todayISO}
            challengeDays={challengeDays}
            actions={actions}
          />
        )}
        {tab === 'week' && (
          <WeekView progress={progress} todayISO={todayISO} onSelectDay={setSelectedIso} />
        )}
        {tab === 'month' && (
          <MonthView progress={progress} todayISO={todayISO} onSelectDay={setSelectedIso} />
        )}
        {tab === 'plan' && <PlanView />}
        {tab === 'data' && <DataView progress={progress} actions={actions} />}
      </main>

      {selectedDay && (
        <DayDetailModal
          day={selectedDay}
          progress={progress}
          todayISO={todayISO}
          actions={actions}
          onClose={closeDay}
        />
      )}
    </div>
  );
}
