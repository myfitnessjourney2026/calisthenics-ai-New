export type Exercise = { name: string; detail: string };

export type DayKind = 'training' | 'rest' | 'not-supplied';

export type DayPlan = {
  kind: DayKind;
  title: string;
  exercises: Exercise[];
};

export type Phase = {
  number: 1 | 2 | 3;
  name: string;
  startDay: number;
  endDay: number;
  focus: string;
  days: DayPlan[];
};

const ex = (name: string, detail: string): Exercise => ({ name, detail });

const training = (title: string, exercises: Exercise[]): DayPlan => ({
  kind: 'training',
  title,
  exercises,
});

const rest: DayPlan = { kind: 'rest', title: 'Rest Day', exercises: [] };

const notSupplied: DayPlan = {
  kind: 'not-supplied',
  title: 'Recovery or plan not supplied',
  exercises: [],
};

// days[0] = Monday ... days[6] = Sunday
export const PHASES: Phase[] = [
  {
    number: 1,
    name: 'Foundation',
    startDay: 1,
    endDay: 30,
    focus: 'Build the base strength and habit',
    days: [
      training('Push + Core', [
        ex('Push-ups', '3 × 5–10'),
        ex('Knee Push-ups', '2 × 8–12'),
        ex('Plank', '3 × 20 seconds'),
      ]),
      training('Legs', [
        ex('Squats', '3 × 15'),
        ex('Lunges', '3 × 10 per leg'),
        ex('Calf Raises', '3 × 20'),
      ]),
      training('Recovery', [
        ex('Walking', '20 minutes'),
        ex('Stretching', '5–10 minutes'),
      ]),
      training('Back + Biceps', [
        ex('Dead Hang', '3 × 15 seconds'),
        ex('Australian Rows', '3 × 8'),
        ex('Superman Hold', '3 × 20 seconds'),
      ]),
      training('Full Body', [
        ex('Push-ups', '3 × 8'),
        ex('Squats', '3 × 15'),
        ex('Mountain Climbers', '2 × 20'),
      ]),
      training('Core', [
        ex('Crunches', '3 × 15'),
        ex('Leg Raises', '3 × 8'),
        ex('Plank', '3 × 30 seconds'),
      ]),
      rest,
    ],
  },
  {
    number: 2,
    name: 'Building',
    startDay: 31,
    endDay: 60,
    focus: 'Increase volume and add pulling work',
    days: [
      training('Push + Core', [
        ex('Push-ups', '3 × 6–12'),
        ex('Diamond Push-ups', '2 × 6–10'),
        ex('Pike Push-ups', '3 × 5–8'),
        ex('Plank', '3 × 25–40 seconds'),
      ]),
      training('Legs', [
        ex('Squats', '3 × 12–20'),
        ex('Reverse Lunges', '3 × 8 per leg'),
        ex('Glute Bridges', '3 × 12'),
        ex('Calf Raises', '3 × 20'),
      ]),
      training('Back + Core', [
        ex('Pull-ups', '3 × 5–8'),
        ex('Hanging Knee Raises', '3 × 10–12'),
        ex('Plank', '3 × 30 seconds'),
      ]),
      notSupplied,
      notSupplied,
      notSupplied,
      rest,
    ],
  },
  {
    number: 3,
    name: 'Advanced',
    startDay: 61,
    endDay: 90,
    focus: 'Master advanced pulling, legs and skills',
    days: [
      training('Advanced Push', [
        ex('Decline Push-ups', '3 × 12'),
        ex('Diamond Push-ups', '3 × 12'),
        ex('Planche Lean', '3 × 15 seconds'),
      ]),
      training('Advanced Pull', [
        ex('Pull-ups', '4 × 5–8'),
        ex('Chin-ups', '3 × 6'),
        ex('Tuck Front Lever', '3 × 5–10 seconds'),
      ]),
      training('Advanced Legs', [
        ex('Bulgarian Split Squat', '3 × 12 per leg'),
        ex('Jump Squats', '3 × 12'),
        ex('Single Leg Calf Raise', '3 × 15 per leg'),
      ]),
      training('Recovery', [
        ex('Walking', '20 minutes'),
        ex('Yoga/Mobility', '10 minutes'),
      ]),
      training('Skill Training', [
        ex('Handstand Practice', '10 minutes'),
        ex('L-Sit', '3 × 10 seconds'),
        ex('Planche Lean', '3 × 15 seconds'),
      ]),
      training('Full Body', [
        ex('Push-ups', '3 × 15'),
        ex('Pull-ups', '3 × 6'),
        ex('Dips', '3 × 8'),
        ex('Squats', '3 × 20'),
        ex('Plank', '3 × 60 seconds'),
      ]),
      rest,
    ],
  },
];
