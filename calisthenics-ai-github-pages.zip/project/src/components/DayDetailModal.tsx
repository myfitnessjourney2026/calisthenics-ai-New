import { useEffect } from 'react';
import { X } from 'lucide-react';
import ExerciseChecklist from '@/components/ExerciseChecklist';
import { DayStatusBadge } from '@/components/DayStatusBadge';
import { getDayStatus, type ProgramDay } from '@/lib/program';
import type { Progress } from '@/lib/progressStorage';
import type { ProgressActions } from '@/hooks/useProgress';
import { formatLongDate } from '@/lib/dates';

type Props = {
  day: ProgramDay;
  progress: Progress;
  todayISO: string;
  actions: Pick<ProgressActions, 'toggleExercise' | 'setDayChecks'>;
  onClose: () => void;
};

export default function DayDetailModal({ day, progress, todayISO, actions, onClose }: Props) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const status = getDayStatus(day, progress, todayISO);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6">
      <button
        type="button"
        aria-label="Close"
        onClick={onClose}
        className="absolute inset-0 animate-[fade-in_0.2s_ease-out] bg-black/70 backdrop-blur-sm"
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={`Workout for ${formatLongDate(day.date)}`}
        className="relative max-h-[90vh] w-full animate-[sheet-up_0.3s_ease-out] overflow-y-auto rounded-t-3xl border border-white/10 bg-zinc-900 p-6 shadow-2xl sm:max-w-lg sm:rounded-3xl"
      >
        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-neon">
              Day {day.dayNumber}
            </p>
            <h3 className="font-display text-xl font-bold text-zinc-50">
              {formatLongDate(day.date)}
            </h3>
            <div className="mt-2">
              <DayStatusBadge status={status} />
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close details"
            className="rounded-xl border border-white/10 p-2 text-zinc-300 transition hover:bg-zinc-800 active:scale-95"
          >
            <X size={20} />
          </button>
        </div>
        <ExerciseChecklist day={day} progress={progress} actions={actions} />
      </div>
    </div>
  );
}
