import type { ReactNode } from 'react';

export function Card({
  children,
  className = '',
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`rounded-3xl border border-white/[0.06] bg-zinc-900/70 p-5 shadow-[0_8px_30px_rgba(0,0,0,0.35)] backdrop-blur sm:p-6 ${className}`}
    >
      {children}
    </div>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  action,
}: {
  eyebrow?: string;
  title: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-5 flex items-end justify-between gap-4">
      <div>
        {eyebrow && (
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-neon">{eyebrow}</p>
        )}
        <h2 className="font-display text-2xl font-bold leading-tight text-zinc-50 sm:text-3xl">
          {title}
        </h2>
      </div>
      {action}
    </div>
  );
}

export function ProgressBar({
  percent,
  label,
  size = 'md',
}: {
  percent: number;
  label?: string;
  size?: 'sm' | 'md';
}) {
  const clamped = Math.min(100, Math.max(0, percent));
  return (
    <div>
      {label && (
        <div className="mb-2 flex items-center justify-between text-sm">
          <span className="text-zinc-400">{label}</span>
          <span className="font-semibold tabular-nums text-neon">{clamped}%</span>
        </div>
      )}
      <div
        className={`w-full overflow-hidden rounded-full bg-zinc-800 ${size === 'sm' ? 'h-2' : 'h-3'}`}
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={clamped}
      >
        <div
          className="h-full rounded-full bg-gradient-to-r from-lime-400 to-neon shadow-[0_0_12px_rgba(57,255,20,0.45)] transition-[width] duration-700 ease-out"
          style={{ width: `${clamped}%` }}
        />
      </div>
    </div>
  );
}

export function StatTile({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <div className="rounded-2xl border border-white/[0.06] bg-zinc-950/60 p-4">
      <p className="text-xs font-medium uppercase tracking-wider text-zinc-500">{label}</p>
      <p className="mt-1 font-display text-2xl font-bold tabular-nums text-zinc-50">{value}</p>
      {hint && <p className="mt-1 text-xs text-zinc-500">{hint}</p>}
    </div>
  );
}

export function PeriodButton({
  label,
  onClick,
  disabled = false,
  children,
}: {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      disabled={disabled}
      className="rounded-xl border border-white/10 bg-zinc-900 p-2.5 text-zinc-200 transition hover:border-neon/40 hover:text-neon active:scale-95 disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:border-white/10 disabled:hover:text-zinc-200"
    >
      {children}
    </button>
  );
}
