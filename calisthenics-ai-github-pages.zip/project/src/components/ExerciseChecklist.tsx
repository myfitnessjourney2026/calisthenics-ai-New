import { Check, RotateCcw, CheckCheck, Moon, Info } from 'lucide-react';
import { ProgressBar } from '@/components/ui';
import { countDayExercises, type ProgramDay } from '@/lib/program';
import type { Progress } from '@/lib/progressStorage';
import type { ProgressActions } from '@/hooks/useProgress';
import { formatLongDate } from '@/lib/dates';

type Props = {
  day: ProgramDay;
  progress: Progress;
  actions: Pick<ProgressActions, 'toggleExercise' | 'setDayChecks'>;
};

export default function ExerciseChecklist({ day, progress, actions }: Props) {
  const plan = day.plan;

  if (!plan) {
    return (
      <div className="rounded-2xl border border-white/[0.06] bg-zinc-950/60 p-5 text-zinc-400">
        This date is outside your 90-day challenge.
      </div>
    );
  }

  if (plan.kind !== 'training') {
    return (
      <div className="flex items-start gap-4 rounded-2xl border border-white/[0.06] bg-zinc-950/60 p-5">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-zinc-800 text-zinc-300">
          {plan.kind === 'rest' ? <Moon size={20} /> : <Info size={20} />}
        </div>
        <div>
          <p className="font-semibold text-zinc-100">{plan.title}</p>
          <p className="mt-1 text-sm leading-relaxed text-zinc-400">
            {plan.kind === 'rest'
              ? 'Rest is part of the program. Sleep, eat well and let your muscles recover.'
              : 'No exercises were supplied for this day, so there is nothing to tick. Use it for light recovery.'}
          </p>
        </div>
      </div>
    );
  }

  const checked = new Set(progress.checks[day.iso] ?? []);
  const { total, done } = countDayExercises(day, progress);
  const percent = total > 0 ? Math.round((done / total) * 100) : 0;
  const allNames = plan.exercises.map((e) => e.name);

  return (
    <div>
      <div className="mb-5">
        <p className="text-sm text-zinc-500">{formatLongDate(day.date)}</p>
        <p className="font-display text-xl font-bold text-zinc-50">{plan.title}</p>
        <ProgressBar percent={percent} label={`${done} of ${total} exercises done`} />
      </div>

      <ul className="space-y-3">
        {plan.exercises.map((exercise) => {
          const isChecked = checked.has(exercise.name);
          return (
            <li key={exercise.name}>
              <label
                className={`group flex cursor-pointer items-center gap-4 rounded-2xl border p-4 transition-all duration-300 active:scale-[0.99] ${
                  isChecked
                    ? 'border-neon/40 bg-neon/[0.07]'
                    : 'border-white/[0.06] bg-zinc-950/50 hover:border-white/15 hover:bg-zinc-800/50'
                }`}
              >
                <input
                  type="checkbox"
                  className="peer sr-only"
                  checked={isChecked}
                  onChange={() => actions.toggleExercise(day.iso, exercise.name)}
                />
                <span
                  className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border-2 transition-all duration-300 peer-focus-visible:ring-2 peer-focus-visible:ring-neon/60 ${
                    isChecked
                      ? 'scale-105 border-neon bg-neon text-zinc-950'
                      : 'border-zinc-600 bg-zinc-900 text-transparent group-hover:border-zinc-400'
                  }`}
                >
                  <Check size={18} strokeWidth={3} />
                </span>
                <span className="min-w-0 flex-1">
                  <span
                    className={`block font-semibold transition-colors ${
                      isChecked ? 'text-zinc-500 line-through decoration-neon/60' : 'text-zinc-100'
                    }`}
                  >
                    {exercise.name}
                  </span>
                  <span className="block text-sm text-zinc-400">{exercise.detail}</span>
                </span>
              </label>
            </li>
          );
        })}
      </ul>

      <div className="mt-5 grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => actions.setDayChecks(day.iso, allNames)}
          disabled={done === total}
          className="flex items-center justify-center gap-2 rounded-xl bg-neon px-4 py-3 text-sm font-semibold text-zinc-950 shadow-[0_0_18px_rgba(57,255,20,0.25)] transition hover:brightness-110 active:scale-[0.98] disabled:cursor-not-allowed disabled:bg-zinc-800 disabled:text-zinc-500 disabled:shadow-none"
        >
          <CheckCheck size={18} />
          Mark all complete
        </button>
        <button
          type="button"
          onClick={() => actions.setDayChecks(day.iso, [])}
          disabled={done === 0}
          className="flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-zinc-800 px-4 py-3 text-sm font-semibold text-zinc-200 transition hover:bg-zinc-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
        >
          <RotateCcw size={16} />
          Reset daily workout
        </button>
      </div>
    </div>
  );
}
