export type BarItem = { label: string; percent: number; muted?: boolean; highlight?: boolean };

export default function BarChart({ bars }: { bars: BarItem[] }) {
  return (
    <div className="flex items-end gap-2 sm:gap-3">
      {bars.map((bar) => {
        const height = bar.muted ? 0 : Math.min(100, Math.max(0, bar.percent));
        return (
          <div key={bar.label} className="flex min-w-0 flex-1 flex-col items-center gap-2">
            <span
              className={`text-xs font-semibold tabular-nums ${bar.highlight ? 'text-neon' : 'text-zinc-400'}`}
            >
              {bar.muted ? '-' : `${bar.percent}%`}
            </span>
            <div className="flex h-36 w-full items-end overflow-hidden rounded-xl bg-zinc-800/60">
              <div
                className={`w-full rounded-xl transition-[height] duration-700 ease-out ${
                  bar.highlight
                    ? 'bg-gradient-to-t from-lime-500 to-neon shadow-[0_0_16px_rgba(57,255,20,0.35)]'
                    : 'bg-gradient-to-t from-emerald-700 to-emerald-400'
                }`}
                style={{ height: `${height}%` }}
              />
            </div>
            <span
              className={`truncate text-xs ${bar.highlight ? 'font-semibold text-zinc-100' : 'text-zinc-500'}`}
            >
              {bar.label}
            </span>
          </div>
        );
      })}
    </div>
  );
}
