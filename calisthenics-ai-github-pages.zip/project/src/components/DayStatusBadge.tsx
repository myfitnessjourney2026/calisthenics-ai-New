import { STATUS_META } from '@/lib/statusStyles';
import type { DayStatus } from '@/lib/program';

export function DayStatusBadge({ status }: { status: DayStatus }) {
  const meta = STATUS_META[status];
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${meta.badge}`}
    >
      {meta.label}
    </span>
  );
}
