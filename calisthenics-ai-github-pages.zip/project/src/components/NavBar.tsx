import { LayoutDashboard, CalendarDays, CalendarRange, ListChecks, Database, Dumbbell } from 'lucide-react';

export type TabId = 'today' | 'week' | 'month' | 'plan' | 'data';

const TABS: { id: TabId; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'today', label: 'Today', icon: LayoutDashboard },
  { id: 'week', label: 'Week', icon: CalendarDays },
  { id: 'month', label: 'Month', icon: CalendarRange },
  { id: 'plan', label: 'Plan', icon: ListChecks },
  { id: 'data', label: 'Data', icon: Database },
];

type Props = {
  active: TabId;
  onChange: (tab: TabId) => void;
};

export function BrandMark() {
  return (
    <div className="flex items-center gap-3">
      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-neon text-zinc-950 shadow-[0_0_20px_rgba(57,255,20,0.35)]">
        <Dumbbell size={22} strokeWidth={2.5} />
      </div>
      <div className="leading-tight">
        <p className="font-display text-sm font-bold tracking-wide text-zinc-50 sm:text-base">
          90-DAY CALISTHENICS
        </p>
        <p className="text-xs text-zinc-500">Body Transformation Tracker</p>
      </div>
    </div>
  );
}

export default function NavBar({ active, onChange }: Props) {
  return (
    <>
      <header className="sticky top-0 z-30 hidden border-b border-white/[0.06] bg-zinc-950/85 backdrop-blur-xl md:block">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-6 px-6 py-4">
          <BrandMark />
          <nav className="flex gap-1 rounded-2xl border border-white/[0.06] bg-zinc-900/80 p-1">
            {TABS.map((tab) => (
              <TabButton key={tab.id} tab={tab} active={active === tab.id} onChange={onChange} />
            ))}
          </nav>
        </div>
      </header>

      <div className="sticky top-0 z-30 border-b border-white/[0.06] bg-zinc-950/90 px-4 py-3 backdrop-blur-xl md:hidden">
        <BrandMark />
      </div>

      <nav
        aria-label="Main navigation"
        className="fixed inset-x-0 bottom-0 z-30 border-t border-white/[0.08] bg-zinc-950/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl md:hidden"
      >
        <div className="mx-auto grid max-w-md grid-cols-5">
          {TABS.map((tab) => (
            <TabButton key={tab.id} tab={tab} active={active === tab.id} onChange={onChange} compact />
          ))}
        </div>
      </nav>
    </>
  );
}

function TabButton({
  tab,
  active,
  onChange,
  compact = false,
}: {
  tab: (typeof TABS)[number];
  active: boolean;
  onChange: (tab: TabId) => void;
  compact?: boolean;
}) {
  const Icon = tab.icon;
  return (
    <button
      type="button"
      onClick={() => onChange(tab.id)}
      aria-current={active ? 'page' : undefined}
      className={`flex items-center justify-center gap-2 rounded-xl transition-all duration-300 active:scale-95 ${
        compact ? 'flex-col py-2.5 text-[11px] font-medium' : 'px-4 py-2.5 text-sm font-semibold'
      } ${
        active
          ? 'bg-neon text-zinc-950 shadow-[0_0_18px_rgba(57,255,20,0.3)]'
          : 'text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100'
      }`}
    >
      <Icon size={compact ? 20 : 18} strokeWidth={2.2} />
      <span>{tab.label}</span>
    </button>
  );
}
