import type { DayStatus } from '@/lib/program';

export const STATUS_META: Record<DayStatus, { label: string; badge: string; cell: string }> = {
  completed: {
    label: 'Completed',
    badge: 'bg-neon/15 text-neon border-neon/40',
    cell: 'bg-neon text-zinc-950 font-bold shadow-[0_0_14px_rgba(57,255,20,0.35)]',
  },
  partial: {
    label: 'In progress',
    badge: 'bg-amber-400/10 text-amber-300 border-amber-400/40',
    cell: 'bg-neon/15 text-neon border border-neon/50',
  },
  missed: {
    label: 'Missed',
    badge: 'bg-rose-500/10 text-rose-300 border-rose-500/40',
    cell: 'bg-rose-500/15 text-rose-300 border border-rose-500/40',
  },
  upcoming: {
    label: 'Upcoming',
    badge: 'bg-zinc-800 text-zinc-300 border-zinc-700',
    cell: 'bg-zinc-900 text-zinc-200 border border-zinc-800',
  },
  rest: {
    label: 'Rest',
    badge: 'bg-zinc-800/60 text-zinc-400 border-zinc-700',
    cell: 'bg-zinc-900/60 text-zinc-500 border border-zinc-800/80',
  },
  'not-supplied': {
    label: 'Not supplied',
    badge: 'bg-zinc-800/60 text-zinc-400 border-zinc-600 border-dashed',
    cell: 'bg-transparent text-zinc-500 border border-dashed border-zinc-700',
  },
  outside: {
    label: 'Outside plan',
    badge: 'bg-transparent text-zinc-600 border-zinc-800',
    cell: 'bg-transparent text-zinc-700',
  },
};
