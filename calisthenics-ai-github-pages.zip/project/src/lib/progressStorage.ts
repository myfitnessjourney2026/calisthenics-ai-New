import { isValidISODate } from '@/lib/dates';

export type Progress = {
  startDate: string;
  checks: Record<string, string[]>;
};

const STORAGE_KEY = 'calisthenics-90-day-progress';
const EXPORT_APP_ID = 'calisthenics-90-day-tracker';

export function createDefaultProgress(todayISO: string): Progress {
  return { startDate: todayISO, checks: {} };
}

export function parseProgress(value: unknown): Progress | null {
  if (typeof value !== 'object' || value === null) return null;
  const { startDate, checks } = value as Record<string, unknown>;
  if (typeof startDate !== 'string' || !isValidISODate(startDate)) return null;
  if (typeof checks !== 'object' || checks === null || Array.isArray(checks)) return null;

  const cleanChecks: Record<string, string[]> = {};
  for (const [iso, names] of Object.entries(checks)) {
    if (!isValidISODate(iso) || !Array.isArray(names)) return null;
    cleanChecks[iso] = names.filter((name): name is string => typeof name === 'string');
  }
  return { startDate, checks: cleanChecks };
}

export function loadProgress(todayISO: string): Progress {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = parseProgress(JSON.parse(raw));
      if (parsed) return parsed;
    }
  } catch {
    return createDefaultProgress(todayISO);
  }
  return createDefaultProgress(todayISO);
}

export function saveProgress(progress: Progress): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch {
    // Storage can be full or blocked in private browsing; the tracker keeps working in memory.
  }
}

export function serializeProgressExport(progress: Progress): string {
  return JSON.stringify({ app: EXPORT_APP_ID, version: 1, ...progress }, null, 2);
}
