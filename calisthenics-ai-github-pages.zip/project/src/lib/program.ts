import { PHASES, type DayPlan, type Phase } from '@/data/workoutPlan';
import { addDays, daysBetween, parseISODate, toISODate, weekdayIndex } from '@/lib/dates';
import type { Progress } from '@/lib/progressStorage';

export const PROGRAM_LENGTH = 90;

export type ProgramDay = {
  date: Date;
  iso: string;
  dayNumber: number;
  phase: Phase | null;
  plan: DayPlan | null;
};

export type DayStatus =
  | 'outside'
  | 'upcoming'
  | 'rest'
  | 'not-supplied'
  | 'completed'
  | 'partial'
  | 'missed';

export type PeriodSummary = {
  total: number;
  done: number;
  percent: number;
  completedDays: number;
  missedDays: number;
  trainingDays: number;
};

export function buildProgramDay(startISO: string, date: Date): ProgramDay {
  const dayNumber = daysBetween(parseISODate(startISO), date) + 1;
  const phase = PHASES.find((p) => dayNumber >= p.startDay && dayNumber <= p.endDay) ?? null;
  const plan = phase ? phase.days[weekdayIndex(date)] : null;
  return { date, iso: toISODate(date), dayNumber, phase, plan };
}

export function buildDateRange(startISO: string, first: Date, count: number): ProgramDay[] {
  return Array.from({ length: count }, (_, i) => buildProgramDay(startISO, addDays(first, i)));
}

export function buildChallengeDays(startISO: string): ProgramDay[] {
  return buildDateRange(startISO, parseISODate(startISO), PROGRAM_LENGTH);
}

export function countDayExercises(day: ProgramDay, progress: Progress): { total: number; done: number } {
  if (!day.plan || day.plan.kind !== 'training') return { total: 0, done: 0 };
  const checked = new Set(progress.checks[day.iso] ?? []);
  const done = day.plan.exercises.filter((e) => checked.has(e.name)).length;
  return { total: day.plan.exercises.length, done };
}

export function getDayStatus(day: ProgramDay, progress: Progress, todayISO: string): DayStatus {
  if (!day.plan) return 'outside';
  if (day.plan.kind === 'rest') return 'rest';
  if (day.plan.kind === 'not-supplied') return 'not-supplied';

  const { total, done } = countDayExercises(day, progress);
  if (total > 0 && done === total) return 'completed';
  if (done > 0) return 'partial';
  if (day.iso < todayISO) return 'missed';
  return 'upcoming';
}

export function summarizeDays(
  days: ProgramDay[],
  progress: Progress,
  todayISO: string,
): PeriodSummary {
  const summary: PeriodSummary = {
    total: 0,
    done: 0,
    percent: 0,
    completedDays: 0,
    missedDays: 0,
    trainingDays: 0,
  };

  for (const day of days) {
    const status = getDayStatus(day, progress, todayISO);
    if (status === 'outside' || status === 'rest' || status === 'not-supplied') continue;

    const { total, done } = countDayExercises(day, progress);
    summary.total += total;
    summary.done += done;
    summary.trainingDays += 1;
    if (status === 'completed') summary.completedDays += 1;
    if (status === 'missed') summary.missedDays += 1;
  }

  summary.percent = summary.total > 0 ? Math.round((summary.done / summary.total) * 100) : 0;
  return summary;
}
