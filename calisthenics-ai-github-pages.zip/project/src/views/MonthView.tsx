import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import BarChart from '@/components/BarChart';
import { STATUS_META } from '@/lib/statusStyles';
import { Card, PeriodButton, ProgressBar, SectionHeading, StatTile } from '@/components/ui';
import { parseISODate, startOfMonth, weekdayIndex } from '@/lib/dates';
import {
  buildDateRange,
  getDayStatus,
  summarizeDays,
  type ProgramDay,
} from '@/lib/program';
import type { Progress } from '@/lib/progressStorage';

const WEEKDAY_HEADERS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const LEGEND: { label: string; cell: string }[] = [
  { label: 'Completed', cell: STATUS_META.completed.cell },
  { label: 'In progress', cell: STATUS_META.partial.cell },
  { label: 'Missed', cell: STATUS_META.missed.cell },
  { label: 'Rest or recovery', cell: STATUS_META.rest.cell },
];

type Props = {
  progress: Progress;
  todayISO: string;
  onSelectDay: (iso: string) => void;
};

export default function MonthView({ progress, todayISO, onSelectDay }: Props) {
  const [monthOffset, setMonthOffset] = useState(0);
  const today = parseISODate(todayISO);
  const first = startOfMonth(today.getFullYear(), today.getMonth() + monthOffset);
  const monthLength = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
  const days = buildDateRange(progress.startDate, first, monthLength);
  const summary = summarizeDays(days, progress, todayISO);

  const leading = weekdayIndex(first);
  const cells: (ProgramDay | null)[] = [...Array<null>(leading).fill(null), ...days];
  while (cells.length % 7 !== 0) cells.push(null);

  const weeks: (ProgramDay | null)[][] = [];
  for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));

  const weekBars = weeks.map((row, index) => {
    const inMonth = row.filter((d): d is ProgramDay => d !== null);
    const weekSummary = summarizeDays(inMonth, progress, todayISO);
    return {
      label: `Wk ${index + 1}`,
      percent: weekSummary.percent,
      muted: weekSummary.trainingDays === 0,
    };
  });

  const monthTitle = first.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <div className="space-y-6 animate-[fade-up_0.5s_ease-out]">
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-neon">Monthly progress</p>
          <h1 className="font-display text-2xl font-bold text-zinc-50 sm:text-3xl">{monthTitle}</h1>
        </div>
        <div className="flex gap-2">
          <PeriodButton label="Previous month" onClick={() => setMonthOffset((o) => o - 1)}>
            <ChevronLeft size={20} />
          </PeriodButton>
          <PeriodButton
            label="Next month"
            onClick={() => setMonthOffset((o) => o + 1)}
            disabled={monthOffset >= 0}
          >
            <ChevronRight size={20} />
          </PeriodButton>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <div className="mb-4 grid grid-cols-7 gap-1.5 sm:gap-2">
            {WEEKDAY_HEADERS.map((name) => (
              <div key={name} className="pb-1 text-center text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
                {name}
              </div>
            ))}
            {cells.map((day, index) => {
              if (!day) return <div key={`blank-${index}`} />;
              const status = getDayStatus(day, progress, todayISO);
              const isToday = day.iso === todayISO;
              const clickable = day.plan !== null;
              return (
                <button
                  key={day.iso}
                  type="button"
                  disabled={!clickable}
                  onClick={() => onSelectDay(day.iso)}
                  aria-label={`${day.date.toDateString()}, ${STATUS_META[status].label}`}
                  className={`relative flex aspect-square flex-col items-center justify-center rounded-xl text-sm transition duration-200 hover:scale-[1.06] active:scale-95 disabled:cursor-default disabled:hover:scale-100 ${STATUS_META[status].cell} ${
                    isToday ? 'ring-2 ring-white/70 ring-offset-2 ring-offset-zinc-900' : ''
                  }`}
                >
                  <span className="tabular-nums">{day.date.getDate()}</span>
                  {day.phase && (
                    <span className="absolute bottom-1 text-[9px] font-medium opacity-60">
                      D{day.dayNumber}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
          <div className="flex flex-wrap gap-x-4 gap-y-2 border-t border-white/[0.06] pt-4">
            {LEGEND.map((item) => (
              <div key={item.label} className="flex items-center gap-2 text-xs text-zinc-400">
                <span className={`h-3.5 w-3.5 rounded ${item.cell}`} />
                {item.label}
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-6 lg:col-span-2">
          <Card>
            <SectionHeading eyebrow="This month" title="Monthly completion" />
            <ProgressBar percent={summary.percent} label="Exercise completion" />
            <div className="mt-6 grid grid-cols-3 gap-3">
              <StatTile label="Completed" value={String(summary.completedDays)} hint="Days" />
              <StatTile label="Missed" value={String(summary.missedDays)} hint="Days" />
              <StatTile label="Exercises" value={String(summary.done)} hint={`of ${summary.total}`} />
            </div>
          </Card>

          <Card>
            <SectionHeading eyebrow="Chart" title="Week by week" />
            <BarChart bars={weekBars} />
          </Card>
        </div>
      </div>
    </div>
  );
}
