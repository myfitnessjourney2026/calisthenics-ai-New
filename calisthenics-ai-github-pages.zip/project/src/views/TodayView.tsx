import { Flame, Quote, Timer, Trophy } from 'lucide-react';
import ExerciseChecklist from '@/components/ExerciseChecklist';
import { Card, ProgressBar, SectionHeading, StatTile } from '@/components/ui';
import { MOTIVATIONS } from '@/data/motivation';
import { formatLongDate, parseISODate, startOfWeek, startOfMonth } from '@/lib/dates';
import {
  PROGRAM_LENGTH,
  buildDateRange,
  buildProgramDay,
  summarizeDays,
  type ProgramDay,
} from '@/lib/program';
import type { Progress } from '@/lib/progressStorage';
import type { ProgressActions } from '@/hooks/useProgress';

type Props = {
  progress: Progress;
  todayISO: string;
  challengeDays: ProgramDay[];
  actions: Pick<ProgressActions, 'toggleExercise' | 'setDayChecks'>;
};

function countdownText(dayNumber: number): { headline: string; sub: string } {
  if (dayNumber < 1) {
    const days = 1 - dayNumber;
    return {
      headline: `Starts in ${days} ${days === 1 ? 'day' : 'days'}`,
      sub: 'Get your gear ready and stretch a little today.',
    };
  }
  if (dayNumber > PROGRAM_LENGTH) {
    return { headline: 'Challenge complete', sub: 'You finished all 90 days. Celebrate that win.' };
  }
  const left = PROGRAM_LENGTH - dayNumber;
  return {
    headline: `Day ${dayNumber} of ${PROGRAM_LENGTH}`,
    sub: left === 0 ? 'Final day. Finish strong.' : `${left} ${left === 1 ? 'day' : 'days'} remaining`,
  };
}

export default function TodayView({ progress, todayISO, challengeDays, actions }: Props) {
  const today = parseISODate(todayISO);
  const todayDay = buildProgramDay(progress.startDate, today);
  const dayNumber = todayDay.dayNumber;
  const countdown = countdownText(dayNumber);
  const motivation = MOTIVATIONS[(Math.max(dayNumber, 1) - 1) % MOTIVATIONS.length];

  const weekDays = buildDateRange(progress.startDate, startOfWeek(today), 7);
  const monthStart = startOfMonth(today.getFullYear(), today.getMonth());
  const monthLength = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
  const monthDays = buildDateRange(progress.startDate, monthStart, monthLength);

  const todaySummary = summarizeDays([todayDay], progress, todayISO);
  const weekSummary = summarizeDays(weekDays, progress, todayISO);
  const monthSummary = summarizeDays(monthDays, progress, todayISO);
  const overall = summarizeDays(challengeDays, progress, todayISO);
  const timeElapsed = Math.round((Math.min(Math.max(dayNumber, 0), PROGRAM_LENGTH) / PROGRAM_LENGTH) * 100);

  return (
    <div className="space-y-6 animate-[fade-up_0.5s_ease-out]">
      <section className="relative overflow-hidden rounded-3xl border border-neon/20 bg-gradient-to-br from-zinc-900 via-zinc-900 to-zinc-950 p-6 sm:p-8">
        <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-neon/10 blur-3xl" />
        <p className="text-sm font-medium text-zinc-400">{formatLongDate(today)}</p>
        <h1 className="mt-2 font-display text-3xl font-bold leading-tight text-zinc-50 sm:text-4xl">
          {countdown.headline}
        </h1>
        <p className="mt-2 text-zinc-400">{countdown.sub}</p>
        {todayDay.phase && (
          <span className="mt-4 inline-flex items-center gap-2 rounded-full border border-neon/30 bg-neon/10 px-3 py-1 text-xs font-semibold text-neon">
            <Timer size={14} />
            Phase {todayDay.phase.number}: {todayDay.phase.name} (Days {todayDay.phase.startDay}–
            {todayDay.phase.endDay})
          </span>
        )}
        <div className="mt-6">
          <ProgressBar percent={timeElapsed} label="Challenge time elapsed" size="sm" />
        </div>
      </section>

      <div className="flex items-start gap-4 rounded-2xl border border-white/[0.06] bg-zinc-900/70 p-5">
        <Quote className="mt-0.5 shrink-0 text-neon" size={22} />
        <p className="font-medium leading-relaxed text-zinc-200">{motivation}</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <SectionHeading eyebrow="Daily workout" title="Today's training" />
          <ExerciseChecklist day={todayDay} progress={progress} actions={actions} />
        </Card>

        <div className="space-y-6 lg:col-span-2">
          <Card>
            <SectionHeading eyebrow="Progress" title="Your numbers" />
            <div className="grid grid-cols-3 gap-3 lg:grid-cols-1 xl:grid-cols-3">
              <StatTile label="Today" value={`${todaySummary.percent}%`} hint="Exercises" />
              <StatTile label="This week" value={`${weekSummary.percent}%`} hint="Exercises" />
              <StatTile label="This month" value={`${monthSummary.percent}%`} hint="Exercises" />
            </div>
          </Card>

          <Card>
            <SectionHeading eyebrow="All time" title="Challenge totals" />
            <div className="space-y-5">
              <ProgressBar percent={overall.percent} label="Challenge completion" />
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-2xl bg-zinc-950/60 p-4">
                  <Trophy className="text-neon" size={20} />
                  <p className="mt-2 font-display text-2xl font-bold tabular-nums text-zinc-50">
                    {overall.completedDays}
                  </p>
                  <p className="text-xs text-zinc-500">Workout days completed</p>
                </div>
                <div className="rounded-2xl bg-zinc-950/60 p-4">
                  <Flame className="text-neon" size={20} />
                  <p className="mt-2 font-display text-2xl font-bold tabular-nums text-zinc-50">
                    {overall.done}
                  </p>
                  <p className="text-xs text-zinc-500">Exercises completed</p>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
