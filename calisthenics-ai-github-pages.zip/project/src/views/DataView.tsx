import { useRef, useState } from 'react';
import { Download, HardDrive, Upload, CalendarClock } from 'lucide-react';
import { Card, SectionHeading } from '@/components/ui';
import { isValidISODate } from '@/lib/dates';
import {
  parseProgress,
  serializeProgressExport,
  type Progress,
} from '@/lib/progressStorage';
import type { ProgressActions } from '@/hooks/useProgress';

type Props = {
  progress: Progress;
  actions: Pick<ProgressActions, 'setStartDate' | 'replaceProgress'>;
};

type Notice = { tone: 'success' | 'error'; text: string } | null;

export default function DataView({ progress, actions }: Props) {
  const fileInput = useRef<HTMLInputElement>(null);
  const [notice, setNotice] = useState<Notice>(null);

  const handleExport = () => {
    const blob = new Blob([serializeProgressExport(progress)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `calisthenics-progress-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    setNotice({ tone: 'success', text: 'Your progress file was downloaded.' });
  };

  const handleImport = async (file: File) => {
    let imported: Progress | null = null;
    try {
      imported = parseProgress(JSON.parse(await file.text()));
    } catch {
      imported = null;
    }
    if (!imported) {
      setNotice({ tone: 'error', text: 'That file could not be read. Choose a progress file exported from this tracker.' });
      return;
    }
    if (!window.confirm('Replace your current progress with the imported file?')) return;
    actions.replaceProgress(imported);
    setNotice({ tone: 'success', text: 'Previous progress imported. Your tracker is up to date.' });
  };

  return (
    <div className="space-y-6 animate-[fade-up_0.5s_ease-out]">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-neon">Settings and backup</p>
        <h1 className="font-display text-2xl font-bold text-zinc-50 sm:text-3xl">Your data</h1>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <SectionHeading eyebrow="Schedule" title="Start date" />
          <p className="mb-4 text-sm leading-relaxed text-zinc-400">
            This is Day 1 of your 90-day challenge. Changing it moves the whole schedule, but your ticks stay saved on their dates.
          </p>
          <label className="block">
            <span className="mb-2 block text-sm font-medium text-zinc-300">Challenge start date</span>
            <input
              type="date"
              value={progress.startDate}
              onChange={(event) => {
                if (isValidISODate(event.target.value)) actions.setStartDate(event.target.value);
              }}
              className="w-full rounded-xl border border-white/10 bg-zinc-950 px-4 py-3 text-zinc-100 outline-none transition focus:border-neon/60 focus:ring-2 focus:ring-neon/20 [color-scheme:dark]"
            />
          </label>
        </Card>

        <Card>
          <SectionHeading eyebrow="Storage" title="Where progress is saved" />
          <div className="flex items-start gap-4">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-neon/15 text-neon">
              <HardDrive size={20} />
            </div>
            <p className="text-sm leading-relaxed text-zinc-400">
              Progress is saved automatically in this browser on this device. It does not need an account, and it will not sync to other phones or computers. Clearing your browser data or switching browsers can remove it, so export a backup regularly.
            </p>
          </div>
        </Card>

        <Card>
          <SectionHeading eyebrow="Backup" title="Export progress" />
          <p className="mb-5 text-sm leading-relaxed text-zinc-400">
            Download a JSON file containing all your ticked exercises and your start date.
          </p>
          <button
            type="button"
            onClick={handleExport}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-neon px-4 py-3 text-sm font-semibold text-zinc-950 shadow-[0_0_18px_rgba(57,255,20,0.25)] transition hover:brightness-110 active:scale-[0.98]"
          >
            <Download size={18} />
            Export progress as JSON
          </button>
        </Card>

        <Card>
          <SectionHeading eyebrow="Restore" title="Import previous progress" />
          <p className="mb-5 text-sm leading-relaxed text-zinc-400">
            Choose a backup file you exported earlier. It replaces the progress saved on this device.
          </p>
          <input
            ref={fileInput}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={(event) => {
              const file = event.target.files?.[0];
              event.target.value = '';
              if (file) void handleImport(file);
            }}
          />
          <button
            type="button"
            onClick={() => fileInput.current?.click()}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-zinc-800 px-4 py-3 text-sm font-semibold text-zinc-100 transition hover:bg-zinc-700 active:scale-[0.98]"
          >
            <Upload size={18} />
            Import progress file
          </button>
        </Card>
      </div>

      {notice && (
        <div
          role="status"
          className={`flex items-center gap-3 rounded-2xl border p-4 text-sm font-medium ${
            notice.tone === 'success'
              ? 'border-neon/30 bg-neon/10 text-neon'
              : 'border-rose-500/40 bg-rose-500/10 text-rose-300'
          }`}
        >
          <CalendarClock size={18} className="shrink-0" />
          {notice.text}
        </div>
      )}
    </div>
  );
}
