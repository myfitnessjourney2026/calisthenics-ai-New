import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import BarChart from '@/components/BarChart';
import { DayStatusBadge } from '@/components/DayStatusBadge';
import { Card, PeriodButton, ProgressBar, SectionHeading, StatTile } from '@/components/ui';
import { addDays, formatShortDate, parseISODate, startOfWeek, toISODate } from '@/lib/dates';
import {
  buildDateRange,
  countDayExercises,
  getDayStatus,
  summarizeDays,
} from '@/lib/program';
import type { Progress } from '@/lib/progressStorage';

const WEEKDAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

type Props = {
  progress: Progress;
  todayISO: string;
  onSelectDay: (iso: string) => void;
};

export default function WeekView({ progress, todayISO, onSelectDay }: Props) {
  const [weekOffset, setWeekOffset] = useState(0);
  const today = parseISODate(todayISO);
  const weekStart = addDays(startOfWeek(today), weekOffset * 7);
  const weekEnd = addDays(weekStart, 6);
  const days = buildDateRange(progress.startDate, weekStart, 7);
  const summary = summarizeDays(days, progress, todayISO);

  const bars = days.map((day, index) => {
    const { total, done } = countDayExercises(day, progress);
    return {
      label: WEEKDAY_NAMES[index].slice(0, 3),
      percent: total > 0 ? Math.round((done / total) * 100) : 0,
      muted: total === 0,
      highlight: toISODate(day.date) === todayISO,
    };
  });

  return (
    <div className="space-y-6 animate-[fade-up_0.5s_ease-out]">
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-neon">Weekly progress</p>
          <h1 className="font-display text-2xl font-bold text-zinc-50 sm:text-3xl">
            {formatShortDate(weekStart)} - {formatShortDate(weekEnd)}
          </h1>
        </div>
        <div className="flex gap-2">
          <PeriodButton label="Previous week" onClick={() => setWeekOffset((o) => o - 1)}>
            <ChevronLeft size={20} />
          </PeriodButton>
          <PeriodButton
            label="Next week"
            onClick={() => setWeekOffset((o) => o + 1)}
            disabled={weekOffset >= 0}
          >
            <ChevronRight size={20} />
          </PeriodButton>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-2">
          <SectionHeading eyebrow="This week" title="Completion" />
          <ProgressBar percent={summary.percent} label="Weekly exercise completion" />
          <div className="mt-6 grid grid-cols-3 gap-3">
            <StatTile label="Workouts" value={String(summary.completedDays)} hint="Completed" />
            <StatTile label="Missed" value={String(summary.missedDays)} hint="Days" />
            <StatTile label="Exercises" value={String(summary.done)} hint={`of ${summary.total}`} />
          </div>
        </Card>

        <Card className="lg:col-span-3">
          <SectionHeading eyebrow="Chart" title="Daily completion" />
          <BarChart bars={bars} />
          <p className="mt-4 text-xs text-zinc-500">Grey columns are rest or recovery days with no exercises to tick.</p>
        </Card>
      </div>

      <Card>
        <SectionHeading eyebrow="Monday to Sunday" title="Your week" />
        <ul className="divide-y divide-white/[0.06]">
          {days.map((day, index) => {
            const status = getDayStatus(day, progress, todayISO);
            const { total, done } = countDayExercises(day, progress);
            const isToday = day.iso === todayISO;
            const clickable = day.plan !== null;
            const title = day.plan?.title ?? 'Outside the challenge';
            return (
              <li key={day.iso}>
                <button
                  type="button"
                  disabled={!clickable}
                  onClick={() => onSelectDay(day.iso)}
                  className="flex w-full items-center gap-4 rounded-xl px-2 py-4 text-left transition hover:bg-zinc-800/50 disabled:cursor-default disabled:hover:bg-transparent sm:px-4"
                >
                  <div
                    className={`flex h-12 w-12 shrink-0 flex-col items-center justify-center rounded-xl border ${
                      isToday ? 'border-neon/60 bg-neon/10 text-neon' : 'border-white/[0.06] bg-zinc-950/60 text-zinc-300'
                    }`}
                  >
                    <span className="text-[10px] font-semibold uppercase">{WEEKDAY_NAMES[index].slice(0, 3)}</span>
                    <span className="font-display text-lg font-bold leading-none">{day.date.getDate()}</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold text-zinc-100">{title}</p>
                    <p className="mt-1 text-sm text-zinc-500">
                      {total > 0 ? `${done} of ${total} exercises` : 'No exercises to tick'}
                    </p>
                  </div>
                  <DayStatusBadge status={status} />
                </button>
              </li>
            );
          })}
        </ul>
      </Card>
    </div>
  );
}
