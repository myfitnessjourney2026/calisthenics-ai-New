import { useState } from 'react';
import { Dumbbell, Moon, Info } from 'lucide-react';
import { Card, SectionHeading } from '@/components/ui';
import { PHASES, type DayPlan } from '@/data/workoutPlan';

const WEEKDAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export default function PlanView() {
  const [phaseIndex, setPhaseIndex] = useState(0);
  const phase = PHASES[phaseIndex];

  return (
    <div className="space-y-6 animate-[fade-up_0.5s_ease-out]">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-neon">Your program</p>
        <h1 className="font-display text-2xl font-bold text-zinc-50 sm:text-3xl">90-day workout plan</h1>
        <p className="mt-2 text-sm text-zinc-400">
          Each weekday has its own workout. Phase 2 Thursday to Saturday has no plan supplied.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {PHASES.map((p, index) => {
          const active = index === phaseIndex;
          return (
            <button
              key={p.number}
              type="button"
              onClick={() => setPhaseIndex(index)}
              aria-pressed={active}
              className={`rounded-2xl border p-5 text-left transition-all duration-300 active:scale-[0.98] ${
                active
                  ? 'border-neon/50 bg-neon/10 shadow-[0_0_24px_rgba(57,255,20,0.12)]'
                  : 'border-white/[0.06] bg-zinc-900/70 hover:border-white/15'
              }`}
            >
              <p className={`text-xs font-semibold uppercase tracking-wider ${active ? 'text-neon' : 'text-zinc-500'}`}>
                Phase {p.number}
              </p>
              <p className="mt-1 font-display text-lg font-bold text-zinc-50">{p.name}</p>
              <p className="mt-1 text-sm text-zinc-400">
                Days {p.startDay}–{p.endDay}
              </p>
            </button>
          );
        })}
      </div>

      <Card>
        <SectionHeading
          eyebrow={`Phase ${phase.number} · Days ${phase.startDay}–${phase.endDay}`}
          title={`${phase.name}: ${phase.focus}`}
        />
        <div className="grid gap-4 md:grid-cols-2">
          {phase.days.map((day, index) => (
            <DayPlanCard key={WEEKDAY_NAMES[index]} weekday={WEEKDAY_NAMES[index]} day={day} />
          ))}
        </div>
      </Card>
    </div>
  );
}

function DayPlanCard({ weekday, day }: { weekday: string; day: DayPlan }) {
  const isTraining = day.kind === 'training';
  return (
    <div className="rounded-2xl border border-white/[0.06] bg-zinc-950/60 p-5 transition hover:border-white/15">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-zinc-500">{weekday}</p>
          <p className="font-display text-lg font-bold text-zinc-100">{day.title}</p>
        </div>
        <div
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
            isTraining ? 'bg-neon/15 text-neon' : 'bg-zinc-800 text-zinc-400'
          }`}
        >
          {day.kind === 'training' && <Dumbbell size={18} />}
          {day.kind === 'rest' && <Moon size={18} />}
          {day.kind === 'not-supplied' && <Info size={18} />}
        </div>
      </div>
      {isTraining ? (
        <ul className="space-y-2">
          {day.exercises.map((exercise) => (
            <li
              key={exercise.name}
              className="flex items-center justify-between gap-3 border-b border-white/[0.05] pb-2 last:border-0 last:pb-0"
            >
              <span className="text-zinc-200">{exercise.name}</span>
              <span className="shrink-0 text-sm font-medium tabular-nums text-zinc-400">{exercise.detail}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-zinc-500">
          {day.kind === 'rest' ? 'Rest and recover.' : 'No plan was supplied for this day.'}
        </p>
      )}
    </div>
  );
}
